# FCCT/IRI independent reconstruction

Status: **partial_engineering_run**.
Exact reproduction is not established. Published values below are reference targets.

Processed 20 of 9000 POPE questions. Tolerance: 1 percentage point(s).

| Split | Method | Metric | Measured | Paper | Difference (pp) |
|---|---|---|---:|---:|---:|
| random | regular | accuracy | 90.00 | 83.29 | +6.71 |
| random | regular | f1 | 90.00 | 81.33 | +8.67 |
| random | iri | accuracy | 90.00 | 89.76 | +0.24 |
| random | iri | f1 | 90.00 | 89.32 | +0.68 |

Other benchmark/model/ablation results have not been reproduced by this report.

## Unpublished settings reconstructed locally

- HF converted checkpoint and Transformers backend; author backend unavailable
- COCO val2014, seed 17, 500 images disjoint from all official COCO POPE images
- Original COCO-only POPE; paper Table 2 dataset/run aggregation is not specified
- Up to 6 distinct present-category queries per image; trace query count is not reported in paper
- Gaussian RGB noise sigma 0.2 in [0,1] units, clipped and rounded to uint8
- All queried-category COCO bounding boxes; any-overlap patches after CLIP resize/crop
- Visual groups use before first/after last object patch; interior background patches omitted
- Text groups use all tokens before/after object span after image, excluding last token
- Capitalized single-token Yes matching LLaVA answer convention, full-vocabulary softmax; author token ID unreported
- Undefined RR for clean-corrupted <= 1e-6; no RR clipping
- Image-balanced mean RR, then rank layers; stable layer-index tie break
- IRI captures source activations before injection, applies to last token of every decoding forward
- Canonical Vicuna v1 LLaVA prompt, greedy decoding, binary max 64 tokens
