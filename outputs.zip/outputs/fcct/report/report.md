# FCCT/IRI independent reconstruction

Status: **complete_independent_reconstruction**.
Exact reproduction is not established. Published values below are reference targets.

Processed 9000 of 9000 POPE questions. Tolerance: 1 percentage point(s).

| Split | Method | Metric | Measured | Paper | Difference (pp) |
|---|---|---|---:|---:|---:|
| random | regular | accuracy | 89.03 | 83.29 | +5.74 |
| random | regular | f1 | 88.96 | 81.33 | +7.63 |
| random | iri | accuracy | 89.33 | 89.76 | -0.43 |
| random | iri | f1 | 88.94 | 89.32 | -0.38 |
| popular | regular | accuracy | 85.60 | 81.88 | +3.72 |
| popular | regular | f1 | 85.99 | 80.06 | +5.93 |
| popular | iri | accuracy | 87.07 | 87.67 | -0.60 |
| popular | iri | f1 | 86.90 | 87.07 | -0.17 |
| adversarial | regular | accuracy | 79.20 | 78.96 | +0.24 |
| adversarial | regular | f1 | 80.95 | 77.57 | +3.38 |
| adversarial | iri | accuracy | 81.27 | 85.17 | -3.90 |
| adversarial | iri | f1 | 82.08 | 84.18 | -2.10 |

Other benchmark/model/ablation results have not been reproduced by this report.

## Tracing coverage and recovery-rate protocol

Tracing questions processed: 1371/1371.
Traced image IDs: 500.
Sample states: `{"complete": 1300, "excluded_object_outside_crop": 70, "excluded_undefined_or_filtered_gap": 1}`.
Probability-gap signs: `{"negative": 369, "positive": 931, "zero": 1}`.
Aggregation: `image_mean`. RR values are not clipped.

## IRI layer selection

Layer numbers below are zero based.

| Component | Source layers | Target layers | Scale |
|---|---|---|---:|
| attention | [13, 14, 17] | [3, 11, 13, 14, 17, 19, 20, 21, 25, 30] | 0.26 |
| mlp | [14, 16, 31] | [2, 9, 14, 16, 17, 22, 24, 28, 30, 31] | 0.16 |

RR weighting: `True`; norm preservation: `True`.

## Recovery-rate curves

![FCCT recovery-rate curves](fcct_curves.png)

## Unpublished settings reconstructed locally

- HF converted checkpoint and Transformers backend; author backend unavailable
- COCO val2014, seed 17, 500 images disjoint from all official COCO POPE images
- Original COCO-only POPE; paper Table 2 dataset/run aggregation is not specified
- Up to 6 distinct present-category queries per image; trace query count is not reported in paper
- Gaussian RGB noise sigma 0.2 in [0,1] units, clipped and rounded to uint8
- All queried-category COCO bounding boxes; any-overlap patches after CLIP resize/crop
- Visual groups use before first/after last object patch; interior background patches omitted
- Text groups use all tokens before/after object span after image, excluding last token
- Capitalized single-token Yes matching LLaVA answer convention, full-vocabulary softmax; author token ID unreported
- Equation 2 applies to positive and negative gaps; only zero denominator is undefined by default
- Image-balanced mean RR, then rank layers; stable layer-index tie break
- IRI captures source activations before injection, applies to last token of every decoding forward
- Canonical Vicuna v1 LLaVA prompt, greedy decoding, binary max 64 tokens

## Additional local analyses

- [Table 6 controls](../ablations/ablation_report.md)
