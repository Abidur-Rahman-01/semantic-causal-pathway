# Table 6: independent IRI ablation controls

Published parameters are frozen. Original implementation and hidden-state intervention semantics remain unavailable.

| Setting | Questions | Measured accuracy | Paper accuracy | Measured F1 | Paper F1 | State |
|---|---:|---:|---:|---:|---:|---|
| Regular | 0 | - | 78.96 | - | 77.57 | not_run |
| IRI without MLP | 5 | 100.00 | 84.93 | 100.00 | 84.02 | partial |
| IRI without MHSA | 0 | - | 85.07 | - | 84.03 | not_run |
| IRI with hidden states | 0 | - | 84.50 | - | 83.67 | not_implemented |
| IRI first ten layers | 0 | - | 78.46 | - | 77.23 | not_run |
| IRI last ten layers | 0 | - | 80.42 | - | 79.87 | not_run |
| IRI one source layer | 0 | - | 82.92 | - | 83.13 | not_run |
| IRI five source layers | 0 | - | 84.76 | - | 83.94 | not_run |
| IRI five target layers | 0 | - | 83.32 | - | 82.71 | not_run |
| IRI fifteen target layers | 0 | - | 84.49 | - | 83.56 | not_run |
| IRI without RR weights | 0 | - | 84.42 | - | 83.92 | not_run |
| IRI without normalization | 0 | - | 85.07 | - | 83.98 | not_run |
| IRI | 0 | - | 85.17 | - | 84.18 | not_run |

## Interpretation choices

- First/last-ten controls independently rank source and target RRs within the specified window.
- Without-RR control retains RR-based layer selection but replaces injection weights with one; author implementation is unavailable.
- No hyperparameter optimization or test-score fitting is performed by this runner.
